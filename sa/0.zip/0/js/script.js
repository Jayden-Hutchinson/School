const clickEvent = "click";
const startButtonID = "start-button";

const startButton = document.getElementById(startButtonID);

startButton.addEventListener(clickEvent, () => {});
