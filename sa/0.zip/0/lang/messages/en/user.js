export const messages = {
    start: "How many buttons to create?",
    startButton: "Start!",
    success: "Excellent Memory!",
    fail: "Wrong Order!",
}